<?php

session_start();
if (isset($_SESSION['id']) && isset($_SESSION['username'])) {
    include_once('inc/connections.php');
    $id = $_SESSION['id'];
    $user = $_SESSION['username'];
} else {
    header("Location: index.php");
    exit();
}


?>

<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- ===== BOX ICONS ===== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
    <!-- ===== CSS ===== -->
    <link rel="stylesheet" type="text/css" href="home.css" />
    <title>MediDonation</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" >
</head>

<body>
    <section class=" top-txt ">
        <div class="head container ">
            <div class="head-txt ">
                <p>MediDonation</p>
            </div>
            <div class="sing_in_up ">
                <?php
                if (isset($_SESSION['username'])) {
                ?>
                    <a href="logout.php">Log Out</a>
                    <a href="profile.php">Profile</a>
                <?php
                } else {
                ?>
                    <a href="index.php">Log In</a>
                <?php
                }
                ?>
            </div>
        </div>
    </section>
    <nav class="navbar navbar-light" style="background-color: #e3f2fd">
        <div class="navbar-container">
            <input type="checkbox" name="" id="checkbox">
            <div class="hamburger-lines">
                <span class="line line1"></span>
                <span class="line line2"></span>
                <span class="line line3"></span>
            </div>
            <ul class="menu-items">
                <li><a href="home.php">Home</a></li>
                <li><a href="Browse.php">Browse Donations</a></li>
                <li><a href="requested.php">Requested Medication</a></li>
                <li><a href="Donate.php">Donate Medication</a></li>
                <li><a href="Request.php">Request Medication</a></li>
            </ul>
            <div class="logo">
                <img style="border-radius: 50%;" src="images/logo.png" width="60" height="60" alt="">
            </div>
        </div>
    </nav>
    <section id="sellers">
        <div class="seller container">
            <h2>Medication Donations</h2>



            <input type="search" name="search" class="form-control" id="search" placeholder="nom du médicament">

            <select id="type" class="form-select w-25" aria-label="Default select example">
                <option selected disabled>Type</option>
                <?php $select = mysqli_query($conn, "SELECT DISTINCT med_type FROM `medication`");
                while ($row = mysqli_fetch_assoc($select)) :
                ?>
                    <option value="<?= $row['med_type'] ?>"><?= $row['med_type'] ?></option>

                <?php endwhile; ?>
            </select>

            <select id="etat" class="form-select w-25" aria-label="Default select example">
                <option selected disabled>etat</option>
                <?php $select = mysqli_query($conn, "SELECT DISTINCT etat  FROM `medication`");
                while ($row = mysqli_fetch_assoc($select)) :
                ?>
                    <option value="<?= $row['etat'] ?>"><?= $row['etat'] ?></option>

                <?php endwhile; ?>
            </select>
            <center>


            <div id="demo">
                <div class="card w-50 mt-5">
                    <?php

                    $med_info = mysqli_query($conn, "SELECT * FROM `medication`");
                    while ($data = mysqli_fetch_array($med_info)):?>
                   <h3><?= $data['med_nom']; ?></h3>

                        <center>
                        <span class="badge badge-warning w-25"><?php if($data['status'] == 2){echo "unavailable";}else{echo "Available";} ?></span><br>
                            <?php echo "<img src='donations/" . $data['picture'] . "'' width='200px'  class='rounded'  alt='profile picture not found'>"; ?>
                        </center>

                        <ul style="list-style:none">
                            <li><?=$data['etat'] ;?></li>
                            <li><?= $data['text'] ;?></li>
                            <li><?= $data['date_creat'] ;?></li>
                        </ul>



                       
                <?php 

                
                
                       
                        $user = $data['user_id'];
                        $info = mysqli_query($conn, "SELECT * FROM `users` WHERE id='$user' ");
                        while ($data_user = mysqli_fetch_array($info)) {
                            echo '<p>Created by ' . $data_user['username'] . '<p>';
                        }
                        echo '<a href="demande.php?id='.$data['post_id'].'" style="padding:8px;background:#222;color:#fff;border:none;cursor:pointer;">DEMANDE</a><hr>';
                    
                    
                    ?>
                    <?php endwhile;?>


                </div>
            </div>
            </center>
    </section>
</body>


</html>


<script src="js/jquery.js"></script>
<script>
    function fill(Value) {



        $('#search').val(Value);



        $('#demo').hide();

    }

    $("#search").change(function() {
            var search = $('#search').val();
            if(search == ""){
                window.location = "Browse.php";
            }
        })

        
    $(document).ready(function() {
        


        $("#type , #etat").change(function() {
            var search = $('#search').val();
            var type = $('#type').val();
            var etat = $('#etat').val();
            if (search == "" && type != "" || etat != "") {
                $.ajax({
                    type: "POST",
                    url: "ajax/search.php",
                    data: {
                        search: search,
                        type: type,
                        etat: etat
                    },
                    success: function(html) {
                        $("#demo").html(html).show();
                    }
                });
            }
        })

    });
</script>