<?php
session_start();
if(isset($_SESSION['id']) && isset($_SESSION['username'])){
include_once('inc/connections.php');
    $id = $_SESSION['id'];
    $user = $_SESSION['username'];
}else{
    header("Location: index.php");
    exit();
}
$info = mysqli_query($conn,"select * from users where username='$user'");
while($data = mysqli_fetch_array($info)){
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $med_nom  =  htmlentities(mysqli_real_escape_string($conn,$_POST['med_nom']));
    $text =  htmlentities(mysqli_real_escape_string($conn,$_POST['text']));
    $error = [];

    if(!$med_nom) {
        $errors[] = "Veuillez entrer le nom de médicament";
    }elseif(strlen($med_nom) < 3 ){
        $errors[] = "le nom de médicament a un minimum de 3 letters ";
    }elseif(filter_var($med_nom,FILTER_VALIDATE_INT)){ 
        $errors[] = "Veuillez entrer un nom de médicament valide et non un numéro";
    }

    if(!$text) {
        $errors[] = 'Veuillez entrer la description de médicament';
    }elseif(strlen($text) < 10){
        $errors[] = 'la description de médicament a un minimum de 10 letters ';
    }
    if(empty($_FILES["picture"]["name"])){
        $errors[] = 'Veuillez ajouter une photo de le médicament  ';
    }
    if(isset($_POST['etat'])){
        $etat = ($_POST['etat']);
    }elseif(empty($_FILES["etat"])) {
        $errors[] = "Veuillez entrer l'état de médicament";
    }
    
    if(isset($_POST['med_type'])){
        $med_type = ($_POST['med_type']);
    }elseif(empty($_FILES["med_type"])) {
        $errors[] = "Veuillez entrer le type de le médicament";
    }

    if(isset($_POST['quantite'])){
        $quantite = $_POST['quantite'];
    }
    
    if(!isset($errors)){
        $image = $_FILES['picture']['name'];
        $image_size = $_FILES['picture']['size'];
        $image_error = $_FILES['picture']['error'];
        $image_type = $_FILES['picture']['type'];
        $image_tmp = $_FILES['picture']['tmp_name'];  // hello . png
        $file_ext = explode('.',$image);
        $file_actual_ext = strtolower(end($file_ext));
        $allowed  = array('jpg','jpge','png','svg');
        if(in_array($file_actual_ext,$allowed)){
            if($image_error == 0){
                if($image_size < 6000000){
                    $file_new_name =  uniqid('',true).'.'.$image;
                    $target = 'donations/'. $file_new_name;
                    $date_creat = date('Y-m-d H:i:s');
                    $sql = "INSERT INTO medication (med_nom,med_type,text,etat,picture,date_creat,user_id,quantite) 
                    VALUES ('$med_nom','$med_type','$text','$etat','$file_new_name','$date_creat','$id','$quantite')";
                    mysqli_query($conn,$sql); 
                      $sql = "INSERT INTO depot (med_nom,med_type,text,etat,picture,date_creat,user_id,quantite) 
                      VALUES ('$med_nom','$med_type','$text','$etat','$file_new_name','$date_creat','$id','$quantite')";
                      mysqli_query($conn,$sql); 
                    if(!empty($image)){
                        
                        if(move_uploaded_file($_FILES['picture']['tmp_name'],$target)){
                            header('location:Browse.php');
                        }
                    }
                }else{
                    $error[] = 'La photo est trop grande!';
                }
    
            }else{
                $error[] = 'Erreur lors du téléchargement de la photo' ;                
            }
    
        }else{
            $error[] = 'Vous ne pouvez pas télécharger photo de ce type!';
        }
    }


}
}


?>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- ===== BOX ICONS ===== --> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"  />
  <!-- ===== CSS ===== -->
  <link rel="stylesheet" type="text/css" href="home.css" />
  <title>MediDonation</title>
  
</head>

<body>
    <section class=" top-txt ">
        <div class="head container ">
            <div class="head-txt ">
                <p>MediDonation</p>
            </div>
            <div class="sing_in_up ">
<?php

if (isset($_SESSION['username'])) {
   ?>
    <a href="logout.php">Log Out</a>
    <a href="profile.php">Profile</a>
    <?php
} else {
   ?>
    <a href="index.php">Log In</a>
    <?php
}
?>            
            </div>
        </div>
    </section>
    <nav class="navbar navbar-light" style="background-color: #e3f2fd">
        <div class="navbar-container">
            <input type="checkbox" name="" id="checkbox">
            <div class="hamburger-lines">
                <span class="line line1"></span>
                <span class="line line2"></span>
                <span class="line line3"></span>
            </div>
            <ul class="menu-items">
                <li><a href="home.php">Home</a></li>
                <li><a href="Browse.php">Browse Donations</a></li>
                <li><a href="requested.php">Requested Medication</a></li>
                <li><a href="Donate.php">Donate Medication</a></li>
                <li><a href="Request.php">Request Medication</a></li>
            </ul>
            <div class="logo">
            <img style="border-radius: 50%;" src="images/logo.png" width="60" height="60" alt="">
            </div>
        </div>
    </nav>
    <section id="sellers">
        <div class="news-heading">
            <h2>Créer une annonce</h2>
            <p>Help others by donating medications you no longer need.<br>out the form below  to list a new donation</p>
        </div>
        <div class="countiner">
            <?php if(!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error):?>
                <div><?php echo '- ' .$error ;?></div>
                <?php endforeach;?>
            </div>
        <?php endif; ?>

        </div>          
            <form action="" id="search-form" method="POST" enctype="multipart/form-data">
                <label for="title">Nom de Medicament</label><br>
                
                <input type="text" name="med_nom" id="med_nom" autocapitalize="on" placeholder="Nom de Medicament"><br>
                <label for="med_type">type</label>
                
                <select name="med_type" titel="choisi le type de médicament" ><option disabled selected value="">Choisi</option><option value='Analgésiques'>Analgésiques</option><option value='Antibiotiques'>Antibiotiques</option><option value='Antiviraux'>Antiviraux</option><option value='Antifongiques'>Antifongiques</option><option value='Antiparasitaires'>Antiparasitaires</option><option value='Antihistaminiques'>Antihistaminiques</option><option value='Anti-inflammatoires'>Anti-inflammatoires</option><option value='Anticoagulants'>Anticoagulants</option><option value='Médicaments cardiovasculaires'>Médicaments cardiovasculaires</option><option value='Psychotropes'>Psychotropes</option></select><br>
                <label for="state">Etat</label>
                
                <select name="etat" titel="choisi l'état de médicament" >
                    <option disabled selected value="">Choisi</option>
                    <option value='Neuf Jamais utilisé'>Neuf Jamais utilisé</option>
                    <option value='Bon état'>Bon état</option>
                    <option value='Etat moyen'>Etat moyen</option>
                </select><br>
                
                <label for="text" name="text" class="form-label">Description</label><br>
                <textarea class="form-control" id="text" name="text" rows="3" required></textarea><br>
                

                <label for="formfile" class="form-label">Quantité</label><br>
                <input class="form-control" name="quantite" value="1" type="number" required id="formFile">



                <label for="formfile" class="form-label">Ajouter une photo du médicament</label><br>
                <input class="form-control" name="picture" type="file" id="formFile">



                <button name="submit" type="submit" class="btn btn-primary">Post</button>            </form>    
        </div>    
    </section>
</form>
</body>
</html>

