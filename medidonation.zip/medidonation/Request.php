<?php
session_start();
if(isset($_SESSION['id']) && isset($_SESSION['username'])){
include_once('inc/connections.php');
    $id = $_SESSION['id'];
    $user = $_SESSION['username'];
}else{
    header("Location: index.php");
    exit();
}
$info = mysqli_query($conn,"select * from users where username='$user'");
while($data = mysqli_fetch_array($info)){
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $medi_nom  =  htmlentities(mysqli_real_escape_string($conn,$_POST['medi_nom']));
    $textt =  htmlentities(mysqli_real_escape_string($conn,$_POST['textt']));
    $error = [];

    if(!$medi_nom) {
        $errors[] = "Veuillez entrer le nom de médicament";
    }elseif(strlen($medi_nom) < 3 ){
        $errors[] = "le nom de médicament a un minimum de 3 letters ";
    }elseif(filter_var($medi_nom,FILTER_VALIDATE_INT)){ 
        $errors[] = "Veuillez entrer un nom de médicament valide et non un numéro";
    }

    if(!$textt) {
        $errors[] = 'Veuillez entrer la description de médicament';
    }elseif(strlen($textt) < 10){
        $errors[] = 'la description de médicament a un minimum de 10 letters ';
    }
    if(empty($_FILES["image"]["name"])){
        $errors[] = 'Veuillez ajouter une photo de le médicament  ';
    }
    
    if(isset($_POST['medi_type'])){
        $medi_type = ($_POST['medi_type']);
    }elseif(empty($_FILES["medi_type"])) {
        $errors[] = "Veuillez entrer le type de le médicament";
    }
    
    if(!isset($errors)){
        $image = $_FILES['image']['name'];
        $image_size = $_FILES['image']['size'];
        $image_error = $_FILES['image']['error'];
        $image_type = $_FILES['image']['type'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $file_ext = explode('.',$image);
        $file_actual_ext = strtolower(end($file_ext));
        $allowed  = array('jpg','jpge','png','svg');
        if(in_array($file_actual_ext,$allowed)){
            if($image_error == 0){
                if($image_size < 6000000){
                    $file_new_name =  uniqid('',true).'.'.$image;
                    $target = 'requests/'. $file_new_name;
                    $date_creat = date('Y-m-d H:i:s');
                    $sql = "INSERT INTO requests (medi_nom,medi_type,textt,image,date_post,userr_id) 
                    VALUES ('$medi_nom','$medi_type','$textt','$file_new_name','$date_post','$id')";
                    if(!empty($image)){
                        mysqli_query($conn,$sql); 
                        if(move_uploaded_file($_FILES['image']['tmp_name'],$target)){
                            header('location:Requested.php');
                        }
                    }
                }else{
                    $error[] = 'La photo est trop grande!';
                }
    
            }else{
                $error[] = 'Erreur lors du téléchargement de la photo' ;                
            }
    
        }else{
            $error[] = 'Vous ne pouvez pas télécharger photo de ce type!';
        }
    }


}
}

?>

<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- ===== BOX ICONS ===== --> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"  />
  <!-- ===== CSS ===== -->
  <link rel="stylesheet" type="text/css" href="home.css" />
  <title>MediDonation</title>
</head>

<body>
    <section class=" top-txt ">
        <div class="head container ">
            <div class="head-txt ">
                <p>MediDonation</p>
            </div>
            <div class="sing_in_up ">
<?php
if (isset($_SESSION['username'])) {
   ?>
    <a href="logout.php">Log Out</a>
    <a href="profile.php">Profile</a>
    <?php
} else {
   ?>
    <a href="index.php">Log In</a>
    <?php
}
?>            
            </div>
        </div>
    </section>
    <nav class="navbar navbar-light" style="background-color: #e3f2fd">
        <div class="navbar-container">
            <input type="checkbox" name="" id="checkbox">
            <div class="hamburger-lines">
                <span class="line line1"></span>
                <span class="line line2"></span>
                <span class="line line3"></span>
            </div>
            <ul class="menu-items">
                <li><a href="home.php">Home</a></li>
                <li><a href="Browse.php">Browse Donations</a></li>
                <li><a href="requested.php">Requested Medication</a></li>
                <li><a href="Donate.php">Donate Medication</a></li>
                <li><a href="Request.php">Request Medication</a></li>
            </ul>
            <div class="logo">
            <img style="border-radius: 50%;" src="images/logo.png" width="60" height="60" alt="">
            </div>
        </div>
    </nav>
    <div class="countiner">
            <?php if(!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error):?>
                <div><?php echo '- ' .$error ;?></div>
                <?php endforeach;?>
            </div>
        <?php endif; ?>

        </div> 
    <section id="contact">
        <div class="contact container">
            <div class="container">
                <h2>Request Medication</h2>
                <form action="" id="search-form" method="POST" enctype="multipart/form-data">
                <label for="title">Medicament:</label><br>
                <input type="text" name="medi_nom" id="medi_nom" autocapitalize="on" placeholder="Nom de Medicament"><br>
                
                <label for="medi_type">type</label>
                <select name="medi_type" titel="choisi le type de médicament" ><option disabled selected value="">Choisi</option><option value='Analgésiques'>Analgésiques</option><option value='Antibiotiques'>Antibiotiques</option><option value='Antiviraux'>Antiviraux</option><option value='Antifongiques'>Antifongiques</option><option value='Antiparasitaires'>Antiparasitaires</option><option value='Antihistaminiques'>Antihistaminiques</option><option value='Anti-inflammatoires'>Anti-inflammatoires</option><option value='Anticoagulants'>Anticoagulants</option><option value='Médicaments cardiovasculaires'>Médicaments cardiovasculaires</option><option value='Psychotropes'>Psychotropes</option></select><br>
                
                <label for="textt" name="textt" class="form-label">Description</label><br>
                <textarea class="form-control" id="text" name="textt" rows="3" required></textarea><br>
                
                <label for="formfile" class="form-label">Ajouter une photo du médicament</label><br>
                <input class="form-control" name="image" type="file" id="formFile">
                
                <button type="submit">Submit Request</button>
                </form>
            </div>
        </div>
    </section>
</body>
</html>