<?php
include_once "../inc/connections.php";
if (isset($_POST['search'])) {
    $search = $_POST['search'];
 
   
    $med_info = mysqli_query($conn,"SELECT * FROM `requests` WHERE  medi_nom LIKE '%$search%'");

}
?>



<div class="card">   
<?php 
                while($data = mysqli_fetch_array($med_info)){
                echo'<p>'.$data['medi_nom']. '</p>';?>
                <?php echo "<img src='donations/".$data['image']."'' width='200px'  class='rounded'  alt='profile picture not found'>";?>
                <?php echo'<p>'.$data['medi_type'].'</p>';
                echo'<p>'.$data['textt'].'</p>';
                echo'<p>'.$data['date_post']. '</p>';
                $user = $data['userr_id'];
                $info = mysqli_query($conn,"SELECT * FROM `users` WHERE id='$user' ");
                while($data_user = mysqli_fetch_array($info)){
                    echo '<p>requested by '.$data_user['username'].'<p><br><br>';
                }
}

?>
           

        </div>