<?php

use function PHPSTORM_META\elementType;

include_once "../inc/connections.php";
if (isset($_POST['search']) && isset($_POST['etat']) && isset($_POST['type'])) {
    $search = $_POST['search'];
    $type = $_POST['type'];
    $etat = $_POST['etat'];
    $med_info = mysqli_query($conn,"SELECT * FROM `medication` WHERE  med_nom = '$search' AND  med_type = '$type' AND etat = '$etat'");

}
?>



<div class="card">   
                <?php 
          
                //$med_info = mysqli_query($conn,"SELECT * FROM `medication`");
                while($data = mysqli_fetch_array($med_info)){
                echo'<p>'.$data['med_nom']. '</p>';?>
                <?php echo "<img src='donations/".$data['picture']."'' width='200px'  class='rounded'  alt='profile picture not found'>";?>
                <?php echo'<p>'.$data['etat'].'</p>';
                echo'<p>'.$data['text'].'</p>';
                echo'<p>'.$data['date_creat']. '</p>';
                
                $user = $data['user_id'];
                $info = mysqli_query($conn,"SELECT * FROM `users` WHERE id='$user' ");
                while($data_user = mysqli_fetch_array($info)){
                    echo '<p>created by '.$data_user['username'].'<p><br><br>';
                }
}

?>
           

        </div>