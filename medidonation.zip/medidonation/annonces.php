<?php

session_start();
if(isset($_SESSION['id']) && isset($_SESSION['username'])){
include('public/header.php');
include_once('inc/connections.php');
    $id = $_SESSION['id'];
    $user = $_SESSION['username'];
}else{
    header("Location: index.php");
    exit();
}

$info = mysqli_query($conn,"select * from users where username='$user'");
while($data = mysqli_fetch_array($info)){



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title> 
    <link rel='stylesheet' href="home.css">
</head>
<body>


 

<div class="container" style="width:900px;">

<?php 
$user = mysqli_query($conn,"SELECT * FROM `medication` WHERE user_id='$id' ");
if(mysqli_num_rows($user) < 1){
echo "<center><div class='alert alert-danger w-50' >Aucun médicament n'a été publié</div></center>";
}else{
?>


<h2>Voici votre publications</h2>



<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Post Id</th>
      <th scope="col">User Id</th>
      <th scope="col">Text</th>
      <th scope="col">Medication Type</th>
      <th scope="col">Medication Etat</th>
      <th scope="col">Image</th>
      <th scope="col">Créé à</th>
      <th scope="col">Supprimer</th>
    </tr>
  </thead>
  <tbody>
    <tr>
<?php                                
        $user = mysqli_query($conn,"SELECT * FROM `medication` WHERE user_id='$id' ");
        while($data = mysqli_fetch_array($user)){?>
      <th scope="row"><?php echo $data['post_id'];?></th>
      <td><?php echo $data['user_id'];?></td>
      <td><?php echo $data['text'];?></td>
      <td><?php echo $data['med_nom'];?></td>
      <td><?php echo $data['etat'];?></td>
      <td><?php echo "<img id='img' src='donations/".$data['picture']."'' width='50px'  class='rounded'  alt='profile picture not found'>";?></td>
      <td><?php echo $data['date_creat'];?></td>
      <td><a href="delete.php?id=<?php echo $data['post_id'];?>" class="btn btn-sm btn-danger">Supprimer</a></td>
    </tr>
<?php }?>    
  </tbody>
</table>
</div>
<?php } } ?>


</body>
</html>

