<?php
session_start();
include_once('inc/connections.php');
if (isset($_GET['id'])) {
    $id_med = $_GET['id'];
    $sql = "DELETE FROM `medication` WHERE  post_id='$id_med'";
    mysqli_query($conn, $sql);
    header('Location:annonces.php');
}
