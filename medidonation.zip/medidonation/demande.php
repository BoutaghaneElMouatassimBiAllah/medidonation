<?php 

include_once "inc/connections.php";

if(isset($_GET['id'])){
    $post_id = intval($_GET['id']);
    $update = mysqli_query($conn,"UPDATE `medication` SET  `status`='2' WHERE post_id = '$post_id'");
    header('location:Browse.php');
}