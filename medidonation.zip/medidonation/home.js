$(document).ready(function () {
    $("a").on("click", function (event) {
      if (this.hash !== "") {
        event.preventDefault();
  
        var hash = this.hash;
        $("html, body").animate(
          {
            scrollTop: $(hash).offset().top,
          },
          800,
          function () {
            window.location.hash = hash;
          }
        );
      }
    });
  });
  
  $(".menu-items a").click(function () {
    $("#checkbox").prop("checked", false);
  });
  const searchForm = document.getElementById('search-form');
const medicationNameInput = document.getElementById('medication-name');
const donationsTableBody = document.getElementById('donations-table').getElementsByTagName('tbody')[0];

// Sample data
const donationsData = [
  {
    medication: 'Ibuprofen',
    description: 'Pain reliever',
    donor: 'John Doe',
    quantity: 100,
    dateDonated: '2023-02-14'
  },
  {
    medication: 'Acetaminophen',
    description: 'Fever reducer',
    donor: 'Jane Smith',
    quantity: 200,
    dateDonated: '2023-02-15'
  }
];

// Function to render the donations data as a table
function renderDonationsData(data) {
  donationsTableBody.innerHTML = '';
  data.forEach(donation => {
    const row = donationsTableBody.insertRow();
    const medicationCell = row.insertCell();
    medicationCell.textContent = donation.medication;
    const descriptionCell = row.insertCell();
    descriptionCell.textContent = donation.description;
    const donorCell = row.insertCell();
    donorCell.textContent = donation.donor;
    const quantityCell = row.insertCell();
    quantityCell.textContent = donation.quantity;
    const dateDonatedCell = row.insertCell();
    dateDonatedCell.textContent = donation.dateDonated;
  });
}

// Function to handle the search form submission
function handleSearchFormSubmit(event) {
  event.preventDefault();
  const medicationName = medicationNameInput.value.trim();
  const filteredData = donationsData.filter(donation => donation.medication.toLowerCase().includes(medicationName.toLowerCase()));
  renderDonationsData(filteredData);
}

// Add event listener to search form
searchForm.addEventListener('submit', handleSearchFormSubmit);

// Render the initial data
renderDonationsData(donationsData);
// Add event listener to search form
searchForm.addEventListener('submit', handleSearchFormSubmit);

// Create a new div element to contain the search form
const searchFormContainer = document.getElementById('search-form-container');
const searchForm = document.createElement('form');

// Add a class to the form for styling
searchForm.classList.add('search-form');

// Create the input element for the search query
const searchInput = document.createElement('input');
searchInput.type = 'text';
searchInput.placeholder = 'Search...';
searchInput.name = 'q';

// Create the submit button for the form
const submitButton = document.createElement('button');
submitButton.textContent = 'Search';

// Add the input and button to the form
searchForm.appendChild(searchInput);
searchForm.appendChild(submitButton);

// Add the form to the container
searchFormContainer.appendChild(searchForm);