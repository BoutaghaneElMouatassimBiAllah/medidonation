<?php
session_start();

include_once "inc/connections.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


$email = $_SESSION['email'];


$userr_id = $_SESSION['id'];
$select = "SELECT medication.med_nom,requests.medi_nom,requests.userr_id FROM requests INNER JOIN medication WHERE requests.userr_id = '$userr_id'";
$res = mysqli_query($conn, $select);
while ($row = mysqli_fetch_assoc($res)) {
    if ($row['medi_nom'] == $row['med_nom']) {
       
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'kaidiyakine@gmail.com';
        $mail->Password   = 'kljsgdqqkdfbhpmn';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;
        $mail->setFrom('kaidiyakine@gmail.com');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'The medicine is available now';
  
        $mail->Body = 'The medicine you are looking for is now available '.$row['medi_nom'];
        $mail->send();
    }
}



?>

<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- ===== BOX ICONS ===== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
    <!-- ===== CSS ===== -->
    <link rel="stylesheet" type="text/css" href="home.css" />
    <title>MediDonation</title>
</head>

<body>
    <section class=" top-txt ">
        <div class="head container ">
            <div class="head-txt ">
                <p>MediDonation</p>
            </div>
            <div class="sing_in_up ">

                <?php
           

                if (isset($_SESSION['username'])) {
                ?>
                    <a href="logout.php">Log Out</a>
                    <a href="profile.php">Profile</a>
                <?php
                } else {
                ?>
                    <a href="index.php">Log In</a>
                <?php
                }
                ?>

            </div>
        </div>
    </section>
    <nav class="navbar navbar-light" style="background-color: #e3f2fd">
        <div class="navbar-container">
            <input type="checkbox" name="" id="checkbox">
            <div class="hamburger-lines">
                <span class="line line1"></span>
                <span class="line line2"></span>
                <span class="line line3"></span>
            </div>
            <ul class="menu-items">
                <li><a href="home.php">Home</a></li>
                <li><a href="Browse.php">Browse Donations</a></li>
                <li><a href="requested.php">Requested Medication</a></li>
                <li><a href="Donate.php">Donate Medication</a></li>
                <li><a href="Request.php">Request Medication</a></li>
            </ul>
            <div class="logo">
                <img style="border-radius: 50%;" src="images/logo.png" width="60" height="60" alt="">
            </div>
        </div>
    </nav>
    <section id="home">
        <div class="home_page ">
            <div class="home_img ">
                <img src="images/background.png" alt="img ">
            </div>
            <div class="home_txt ">
                <p class="collectio ">How to Donate Prescription Drugs</p>
                <h2>How to Donate Prescription Drugs</h2>
                <div class="home_label ">
                    <p>Billions of dollars in unused medicine goes to waste annually</p>
                </div>
            </div>
        </div>
    </section>

    <section id="collection">
        <div class="collections container">
            <div class="content">
                <img src="images/Hart.png" alt="img" />
                <div class="img-content">
                    <p>View Donations</p>
                    <button><a href="Browse.php">Check out all the donations you have made or received.</a></button>
                </div>
            </div>
            <div class="content2">
                <img src="images/Plus.png" alt="img" />
                <div class="img-content2">
                    <p>Add Donation</p>
                    <button><a href="Donate.php">Contribute by adding a new donation entry.</a></button>
                </div>
            </div>
            <div class="content3">
                <img src="images/House.png" alt="img" />
                <div class="img-content3">
                    <p>Request Medication</p>
                    <button><a href="Request.php">Need medication? Create a request here.</a></button>
                </div>
            </div>
        </div>
    </section>
    <section id="contact">
        <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3327.2127113838646!2d7.719882160123447!3d36.81400452886256!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12f0091585d50fcd%3A0x87534ba90cfbb01f!2sRectorat%20de%20l&#39;universit%C3%A9%20Badji%20Mokhtar%20-%20Annaba%20(P%C3%B4le%20Universitaire%20Sidi%20Amar)!5e0!3m2!1sen!2sdz!4v1714257113246!5m2!1sen!2sdz" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <form action="https://formspree.io/f/xzbowpjq" method="POST">
            <div class="form">
                <div class="form-txt">
                    <h4>INFORMATION</h4>
                    <h1>Contact Us</h1>
                    <span>As you might expect of a company that began as a high-end interiors contractor, we pay strict
                        attention.</span>
                    <h3>ALGERIA</h3>
                    <p>RP7C+J4M, Sidi-Ammar, Annaba<br>+213 31-00-00-00</p>
                </div>
                <div class="form-details">
                    <input type="text" name="name" id="name" placeholder="Name" required>
                    <input type="email" name="email" id="email" placeholder="Email" required>
                    <textarea name="message" id="message" cols="52" rows="7" placeholder="Message" required></textarea>
                    <button>SEND MESSAGE</button>
                </div>
            </div>
        </form>
        </div>
    </section>
    <footer>
        <div class="footer-container container">
            <div class="content_1">
                <img src="images/logo.png" width="150" height="150" alt="">
                <p>The customer is at the heart of our<br>unique business model, which includes<br>design.</p>
                <img src="https://i.postimg.cc/Nj9dgJ98/cards.png" alt="cards">
            </div>

            <div class="content_3">
                <a href="./contact.html">Contact Us</a>
                <a href="https://payment-method-sb.netlify.app/" target="_blank">Payment Method</a>
                <a href="https://delivery-status-sb.netlify.app/" target="_blank">Delivery</a>
            </div>
            <div class="content_4">
                <h4>NEWLETTER</h4>
                <p>Your donation is crucial in helping us deliver health and hope to those in need.<br>Together, we are making a significant difference.</p>
            </div>
        </div>
        <div class="f-design">
            <div class="f-design-txt container">
                <p>Design and Code by Boutaghane El-Mouatassim Bi-Allah</p>
            </div>
        </div>
    </footer>
    <script src="home.js"></script>
</body>

</html>