<?php

$conn = mysqli_connect('localhost','root','','medidonation');
if(!$conn){
    die('Error '.mysqli_connect_error());

}




 