-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2024 at 03:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medidonation`
--

-- --------------------------------------------------------

--
-- Table structure for table `depot`
--

CREATE TABLE `depot` (
  `post_id` int(11) NOT NULL,
  `med_nom` varchar(255) NOT NULL,
  `med_type` enum('Analgésiques','Antibiotiques','Antiviraux','Antifongiques','Antiparasitaires','Antihistaminiques','Anti-inflammatoires','Anticoagulants','Médicaments cardiovasculaires','Psychotropes') NOT NULL,
  `user_id` int(255) NOT NULL,
  `picture` longtext NOT NULL,
  `date_creat` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `etat` enum('Neuf Jamais utilisé','Bon état','Etat moyen','') NOT NULL,
  `quantite` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `depot`
--

INSERT INTO `depot` (`post_id`, `med_nom`, `med_type`, `user_id`, `picture`, `date_creat`, `text`, `etat`, `quantite`) VALUES
(0, 'dol', 'Antiviraux', 4, '66551b5fb75b81.22665999.doliprane-1000mg-poudre-8-sachets.jpg', '2024-05-28 01:46:39', 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 'Neuf Jamais utilisé', 1);

-- --------------------------------------------------------

--
-- Table structure for table `medication`
--

CREATE TABLE `medication` (
  `post_id` int(11) NOT NULL,
  `med_nom` varchar(255) NOT NULL,
  `med_type` enum('Analgésiques','Antibiotiques','Antiviraux','Antifongiques','Antiparasitaires','Antihistaminiques','Anti-inflammatoires','Anticoagulants','Médicaments cardiovasculaires','Psychotropes') NOT NULL,
  `user_id` int(255) NOT NULL,
  `picture` longtext NOT NULL,
  `date_creat` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `etat` enum('Neuf Jamais utilisé','Bon état','Etat moyen','') NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medication`
--

INSERT INTO `medication` (`post_id`, `med_nom`, `med_type`, `user_id`, `picture`, `date_creat`, `text`, `etat`, `status`) VALUES
(448, 'doliperan', 'Analgésiques', 5, '664a23cb421365.96464376.logo2.png', '2024-05-19 18:07:39', 'gjrioerjgiojergi', 'Neuf Jamais utilisé', 0),
(449, 'dol', 'Antiviraux', 4, '66551b5fb75b81.22665999.doliprane-1000mg-poudre-8-sachets.jpg', '2024-05-28 01:46:39', 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 'Neuf Jamais utilisé', 0);

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `request_id` int(11) NOT NULL,
  `medi_nom` varchar(255) NOT NULL,
  `medi_type` enum('Analgésiques','Antibiotiques','Antiviraux','Antifongiques','Antiparasitaires','Antihistaminiques','Anti-inflammatoires','Anticoagulants','Médicaments cardiovasculaires','Psychotropes') NOT NULL,
  `image` longtext NOT NULL,
  `date_post` varchar(255) NOT NULL,
  `userr_id` int(255) NOT NULL,
  `textt` text NOT NULL,
  `quantite` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`request_id`, `medi_nom`, `medi_type`, `image`, `date_post`, `userr_id`, `textt`, `quantite`) VALUES
(1, 'doliperan', 'Antibiotiques', '664a14325cde97.37646781.Hart.png', '', 4, 'eoihveoiyezui', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `birthday` text NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `md5_pass` varchar(255) NOT NULL,
  `profile_picture` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `birthday`, `gender`, `md5_pass`, `profile_picture`) VALUES
(4, 'mouatassim', 'mouatassemd@gmail.com', '123456789', '4-3-2010', 'male', '25f9e794323b453885f5181f1b624d0b', '663e314430fbe2.71463686.png'),
(5, 'mohamed', 'mouatassemp@gmail.com', '123456789', '4-3-2009', 'male', '25f9e794323b453885f5181f1b624d0b', 'no-profile-picture-male.jpg'),
(6, 'mohamed1', 'moua_tassem@yahoo.com', '123456789', '17-8-2011', 'male', '25f9e794323b453885f5181f1b624d0b', 'no-profile-picture-male.jpg'),
(7, 'meriem', 'boutaghaneelmouatassim@gm', '123456789', '18-2-2007', 'male', '25f9e794323b453885f5181f1b624d0b', 'no-profile-picture-male.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medication`
--
ALTER TABLE `medication`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `medication`
--
ALTER TABLE `medication`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=450;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
