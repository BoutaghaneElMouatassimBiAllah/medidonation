<?php

session_start();
if (isset($_SESSION['id']) && isset($_SESSION['username'])) {

  include_once('inc/connections.php');
  $id = $_SESSION['id'];
  $user = $_SESSION['username'];
} else {
  header("Location: index.php");
  exit();
}

$info = mysqli_query($conn, "select * from users where username='$user'");
while ($data = mysqli_fetch_array($info)) {



?>

  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel='stylesheet' href="home.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
  </head>


  <body>
    <?php include_once 'public/header.php'; ?>

    <!-- Button trigger modal -->


    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Notification</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <?php
            include_once "inc/connections.php";
            $email = $_SESSION['email'];
            $userr_id = $_SESSION['id'];
            $select = "SELECT medication.med_nom,requests.medi_nom,requests.userr_id FROM requests INNER JOIN medication WHERE requests.userr_id = '$userr_id'";
            $res = mysqli_query($conn, $select);
            while ($row = mysqli_fetch_assoc($res)) {
              if ($row['medi_nom'] == $row['med_nom']) {
                echo $row['medi_nom'] . " The medicine you are looking for is now available";
              }
            }

            ?>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

          </div>
        </div>
      </div>
    </div>


    <div class="container" style="width: 800px;">

      <h2>Bienvenue <span><?php echo $user; ?></span> à votre profile</h2>




      <div class="photo">
        <?php echo "<img src='images/" . $data['profile_picture'] . "'' width='200px'  class='rounded'  alt='profile picture not found'>"; ?>
      <?php }
      ?>

      </div>

      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Username</th>
            <th scope="col">Email</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row"><?php echo $_SESSION['id']; ?></th>
            <td><?php echo $_SESSION['username']; ?></td>
            <td><?php echo $_SESSION['email']; ?></td>
          </tr>
        </tbody>
      </table>
      <?php if (isset($error)) {
        echo $error;
      } ?>

      <form action="upload_image.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="file" id="file">
        <input type="submit" class="btn btn-primary" name="submit" value="Télécharger">


      </form>
  </body>

  </html>