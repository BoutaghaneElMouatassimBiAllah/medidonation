<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link  href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/5.0.2/cyborg/bootstrap.min.css"  rel="stylesheet" >
    <link rel="stylesheet" href="home.css">
</head>
<body>
<section class=" top-txt ">
        <div class="head container ">
            <div class="head-txt ">
                <p>MediDonation</p>
            </div>
            <div class="sing_in_up ">


            </div>
        </div>
    </section>
    <nav class="navbar navbar-light" style="background-color: #e3f2fd">
        <div class="navbar-container">
            <input type="checkbox" name="" id="checkbox">
            <div class="hamburger-lines">
                <span class="line line1"></span>
                <span class="line line2"></span>
                <span class="line line3"></span>
            </div>
            <ul class="menu-items">
                <li><a href="home.php">Home</a></li>
                <li><a href="Browse.php">Browse Donations</a></li>
                <li><a href="requested.php">Requested Medication</a></li>
                <li><a href="Donate.php">Donate Medication</a></li>
                <li><a href="Request.php">Request Medication</a></li>
            </ul>
            <div class="logo">
                <img src="images/logo.png" width="70" height="70" alt="">
            </div>
        </div>
    </nav>
  
    <div class="sidebar" >
        <header>Mon Espace</header>
        <ul style="list-style:none;"">
            <li><a  href="annonces.php"><i class="fas fa-qrcode"></i>Mes annonces</a></li>

            <li><a href="" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-link"></i>Notification e-mail</a></li>

            <li><a href="logout.php"><i class="fas fa-stream" href="logout.php"></i>Déconnecté</a></li>
        </ul>
    </div>
</body>
</html>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>