<?php
include('inc/connections.php');
if(isset($_POST['submit'])){
    $username = stripcslashes(strtolower($_POST['username'])) ; 
    $email = stripcslashes($_POST['email']);
    $password = stripcslashes($_POST['password']);
    if(isset($_POST['birthday_month']) && isset($_POST['birthday_day']) && isset($_POST['birthday_year'])){
        $birthday_month = (int)$_POST['birthday_month'];
        $birthday_day  = (int) $_POST['birthday_day'];
        $birthday_year = (int) $_POST['birthday_year'];
        $birthday = htmlentities(mysqli_real_escape_string($conn,$birthday_day.'-'.$birthday_month.'-'.$birthday_year)); 
    }

    $username  =  htmlentities(mysqli_real_escape_string($conn,$_POST['username']));
    $email =      htmlentities(mysqli_real_escape_string($conn,$_POST['email']));
    $passsword  = htmlentities(mysqli_real_escape_string($conn,$_POST['password']));
    $md5_pass = md5($passsword);

if(isset($_POST['gender'])){
    $gender = ($_POST['gender']);
    $gender = htmlentities(mysqli_real_escape_string($conn,$_POST['gender']));
    if(!in_array($gender,['male','female'])){
        $gender_error = '<p id="error" >Veuillez choisir un sexe, pas un text ! <p>';
        $err_s = 1 ;

    }
}

$check_user = "SELECT * FROM `users` WHERE username='$username'";
$check_result = mysqli_query($conn,$check_user);
$num_rows = mysqli_num_rows($check_result);
if($num_rows != 0){
    $user_error = "<p id='error' >Désolé, le nom d'utilisateur existe déjà. Veuillez le changer <p>";
    $err_s = 1 ;
}

$check_user = "SELECT * FROM `users` WHERE email='$email'";
$check_result = mysqli_query($conn,$check_user);
$num_rows = mysqli_num_rows($check_result);
if($num_rows != 0){
    $user_error = "<p id='error' >Désolé, Ce émail existe déjà. Veuillez le changer <p>";
    $err_s = 1 ;
}




if(empty($username)) {
    $user_error = "<p id='error' >Veuillez entrer votre nom d'utilisateur<p>";
    $err_s = 1 ;
}elseif(strlen($username) < 6 ){
    $user_error = "<p id='error' >Votre nom d'utilisateur a un minimum de 6 letters <p>";
     $err_s = 1 ;
}elseif(filter_var($username,FILTER_VALIDATE_INT)){ 
    $user_error = "<p id='error' >Veuillez entrer un nom d'utilisateur valide et non un numéro<p>";
    $err_s = 1 ;
}

if(empty($email)) {
    $email_error = '<p id="error" >Veuillez entrer votre email <p>';
    $err_s = 1 ;
}
elseif(!filter_var($email,FILTER_VALIDATE_EMAIL))
{
    $email_error = '<p id="error" >Veuillez entrer votre un email valid <p>';
    $err_s = 1 ;

}

if(empty($gender)){
    $gender_error = '<p id="error" >Please choose gender <p>';
    $err_s = 1 ;
}
if(empty($birthday)){
    $birthday_error = '<p id="error" >Veuillez entrer votre date de naissance <p> ';
    $err_s = 1 ;
}
if(empty($passsword)){
    $pass_error = '<p id="error" >Veuillez entrer votre mot de passe <p>';
    $err_s = 1 ;
    include('register.php');

}elseif(strlen($passsword) < 8){
    $pass_error = '<p id="error" >Votre mot de pass a un minimum de 8 letters <p> ';
    $err_s = 1 ;
    include('register.php');
}
else{
    if(($err_s == 0) && ($num_rows == 0)){
        if($gender == 'male'){
            $picture = 'no-profile-picture-male.jpg';
        }else{
            $picture = 'no-profile-picture-female.jpg';
        }
        $sql = "INSERT INTO users(username,email,password,birthday,gender,md5_pass,profile_picture) 
        VALUES ('$username','$email','$passsword','$birthday','$gender','$md5_pass','$picture')";
        mysqli_query($conn,$sql);
        header('location:index.php');
    }else{
        include('register.php');
    }
}

}








?>