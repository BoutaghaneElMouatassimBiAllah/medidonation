<?php

session_start();
if(isset($_SESSION['id']) && isset($_SESSION['username'])){
include_once('inc/connections.php');
    $id = $_SESSION['id'];
    $user = $_SESSION['username'];
}else{
    header("Location: index.php");
    exit();
}


?>

<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- ===== BOX ICONS ===== --> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"  />
  <!-- ===== CSS ===== -->
  <link rel="stylesheet" type="text/css" href="home.css" />
  <title>MediDonation</title>
</head>

<body>
    <section class=" top-txt ">
        <div class="head container ">
            <div class="head-txt ">
                <p>MediDonation</p>
            </div>
            <div class="sing_in_up ">
            <?php
if (isset($_SESSION['username'])) {
   ?>
    <a href="logout.php">Log Out</a>
    <a href="profile.php">Profile</a>
    <?php
} else {
   ?>
    <a href="index.php">Log In</a>
    <?php
}
?>            
            </div>
        </div>
    </section>
    <nav class="navbar navbar-light" style="background-color: #e3f2fd">
        <div class="navbar-container">
            <input type="checkbox" name="" id="checkbox">
            <div class="hamburger-lines">
                <span class="line line1"></span>
                <span class="line line2"></span>
                <span class="line line3"></span>
            </div>
            <ul class="menu-items">
                <li><a href="home.php">Home</a></li>
                <li><a href="Browse.php">Browse Donations</a></li>
                <li><a href="requested.php">Requested Medication</a></li>
                <li><a href="Donate.php">Donate Medication</a></li>
                <li><a href="Request.php">Request Medication</a></li>
            </ul>
            <div class="logo">
            <img style="border-radius: 50%;" src="images/logo.png" width="60" height="60" alt="">
            </div>
        </div>
    </nav>
    <section id="sellers">
        <div class="seller container">
            <h2>Medication Requests</h2>
            <form id="search-form" method="GET">
                <label for="search">Search by medication name:</label>
                <input type="search" name="search" class="form-control" id="search" placeholder="nom du médicament">

             <div id="demo">
                
             </div>

<script src="js/jquery.js"></script>
                    <script>
                    

                        function fill(Value) {

                

                            $('#search').val(Value);

              

                            $('#demo').hide();

                        }
                        $(document).ready(function() {
                            $("#search").keyup(function() {
                                var search = $('#search').val();
                            
                                


                                if(search == ""){
                                    window.location ="requested.php";

                                }
                               
                                    

                    
                                    $.ajax({
                                        type: "POST",
                                        url: "ajax/fsearch.php",
                                        data: {
                                            search: search,
                                          
                                        },
                                        success: function(html) {
                                            $("#demo").html(html).show();
                                        }
                                    });
                                
                                
                            })
                                
                        });
                    </script>

            </form>

        </div>
    </section>
</body>
</html>