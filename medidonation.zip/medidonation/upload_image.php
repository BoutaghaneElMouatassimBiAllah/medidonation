<?php

include_once('inc/connections.php');
if(empty($_POST['file'])){
    $error = 'Veuillez choisir une photo à télécharger';
    include_once('profile.php');
}else{
    session_start();
}
if(isset($_SESSION['id']) && isset($_SESSION['username'])){
    $username = $_SESSION['username'];
   

if(isset($_POST['submit'])){

    $file = $_FILES['file'];
    $file_name = $_FILES['file']['name'];
    $file_size = $_FILES['file']['size'];
    $file_error = $_FILES['file']['error'];
    $file_type = $_FILES['file']['type'];
    $file_tmp = $_FILES['file']['tmp_name'];

    $file_ext = explode('.',$file_name);
    $file_actual_ext = strtolower(end($file_ext));
    $allowed  = array('jpg','jpge','png','svg');
    if(in_array($file_actual_ext,$allowed)){
        if($file_error == 0){
            if($file_size < 6000000){
                $file_new_name =  uniqid('',true).'.'.$file_actual_ext;
                $target = 'images/'. $file_new_name;
                $sql = "UPDATE users SET profile_picture='$file_new_name' WHERE username='$username'";
                mysqli_query($conn,$sql); 
                move_uploaded_file($file_tmp,$target);
                header('location:profile.php');


            }else{
                $error = 'La photo est trop grande!';
                include_once('profile.php');
            }

        }else{
            $error = 'Erreur lors du téléchargement de la photo' ;
            include_once('profile.php');
            
        }

    }else{
        $error = 'Vous ne pouvez pas télécharger photo de ce type!';
        include_once('profile.php');
    }
}
}
